package JDBCintro.Lecture;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

//public class ConnectionExmp {
//
//    public static Connection getConnection2( ) throws SQLException, IOException {
//        Connection conn2;
//        Properties props = new Properties ();
//        try (BufferedReader in = Files.newBufferedReader (Paths.get ("app.properties"),Charset.forName ("utf-8" ) )) {
//            props.load(in);
//        }
//        String dbUrl = props.getProperty ("dbUrlAddress");
//        String userName = props.getProperty ("userName");
//        String pass= props.getProperty ("password");
//        conn2 = DriverManager.getConnection (dbUrl, userName, pass);
//     return conn2;
//    }
//}