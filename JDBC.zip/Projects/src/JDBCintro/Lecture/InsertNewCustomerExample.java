package JDBCintro.Lecture;

import java.io.IOException;
import java.sql.*;

import static JDBCintro.Merchant1.DBUtils.Connection.getConnection;


public class InsertNewCustomerExample{
public static void main(String[]args) throws IOException, SQLException {

        Connection con=getConnection();
        String sql="INSERT INTO customer (name, address, email, ccNo, ccType, maturity) values('Clar Nelis', 'Vosselaarst. 19, Trnaut, Belgium', 'Clar@adw.com', '11345694671231', 'MasterCard', '2014-07-31') ";
        Statement stmt=con.createStatement();
        stmt.executeUpdate(sql);
        stmt.close();
        }
}