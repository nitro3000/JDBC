package JDBCintro.Wrong;

import java.sql.*;

// showing all Merchants ***************************************************************************************************
public class MerchantServiceWrong {
    public void paymentTotalAllID() {
        try (Connection con4 = DriverManager.getConnection ("jdbc:mysql://localhost:3306/Cash_management", "root", "Af373737!")) {
            Statement stmt = con4.createStatement ( );
            ResultSet rs = stmt.executeQuery (
                    "SELECT m.id, m.name, m.lastSent, SUM(sumPaid) sum_total\n" +
                            "FROM merchant m,\n" +
                            "     payment p\n" +
                            "group by p.merchantId,m.id\n" +
                            "having SUM(p.sumPaid) and m.id=p.merchantId; ");
            while (rs.next ( )) {
                String merchantID = rs.getString (1);
                String title = rs.getString (2);
                String lastSent = rs.getString (3);
                String sumPaid = rs.getString (4);
                System.out.println ("Merchand ID: " + merchantID +
                        ", Title : " + title + ", Las Sent " + lastSent +
                        ", Total Sum Paid To Merchant : " + sumPaid);
            }
        } catch (
                SQLException ex) {
            System.out.println (ex.getMessage ( ));
        }
    }

    // has to create PreparedStatement to show only Merchant that reminded in the arguments.*********************************
    public void paymentTotalEachID() {
        try (Connection con5 = DriverManager.getConnection ("jdbc:mysql://localhost:3306/Cash_management", "root", "Af373737!")) {
            Statement stmt = con5.createStatement ( );
            ResultSet rs = stmt.executeQuery (
                    "SELECT m.id, m.name, m.lastSent, SUM(sumPaid) sum_total\n" +
                            "FROM merchant m,\n" +
                            "     payment p\n" +
                            "group by p.merchantId,m.id\n" +
                            "having SUM(p.sumPaid) and m.id=p.merchantId " );
            while (rs.next ( )) {
                String merchantID = rs.getString (1);
                String title = rs.getString (2);
                String lastSent = rs.getString (3);
                String sumPaid = rs.getString (4);
                System.out.println ("Merchand ID: " + merchantID +
                        ", Title : " + title + ", Las Sent " + lastSent +
                        ", Total Sum Paid To Merchant : " + sumPaid);
            }
        } catch (
                SQLException ex) {
            System.out.println (ex.getMessage ( ));
        }
    }


}

